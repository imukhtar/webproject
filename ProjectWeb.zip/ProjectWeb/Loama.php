<?php require_once("section/header.php"); ?>
		<p class="con">Loama Resort Maldives at Maamigili</p>
		
		<div class="house">
			<div class="rooms"><img src="img/Loama/rooms2.jpg"></div>
			<div class="rooms"><img src="img/Loama/rooms1.jpg"></div>
			<div class="rooms"><img src="img/Loama/rooms4.jpg"></div>
			<div class="rooms"><img src="img/Loama/rooms5.jpg"></div>
			<div class="rooms"><img src="img/Loama/rooms3.jpg"></div>
			<div class="rooms"><img src="img/Loama/rooms7.jpg"></div>

		</div>
		<div class="aboutText">

			<p class="con">About rooms</p>

			<div class="about_hotel">
				<p>Resort Loama Maldives at Maamigili located in the heart of the oldest historical Raa Atoll, part of the Maldives, surrounded by over 100 acres of pristine coral reef. It features an outdoor infinity pool, 6 restaurants and bars. Guests can enjoy a variety of water sports, as well as go on a luxury private yacht excursions on landing on the islands. It offers free Wi-Fi.
				</p>
				<p>In-room amenities - air conditioning, seating area, television, mini bar, iPod docking station, and a dining area with an electric kettle and coffee machine. The private bathroom with bath or shower and free toiletries.
				</p>
			</div>
		</div>	
		<hr>

		<div class="comments">

			<h4>Comments</h4>

		</div>
		<hr>

		<div class="comments-form">

			<h4>Write comments</h4>

			<p>
				 <span>
				 	<input id="comments-form-name" type="text" name="name" value="" maxlength="20" size="22" tabindex="1" class="">
				 	<label for="comments-form-name">Name</label>
				 </span>
			</p>
			<p>
				<span>
					<input id="comments-form-email" type="text" name="email" value="" size="22" tabindex="2">
					<label for="comments-form-email">E-Mail</label>
				</span>
			</p>
			<p>
				<span>
					<textarea id="comments-form-comment" name="comment" cols="65" rows="8" tabindex="5" class=""></textarea>
				</span>
			</p>
			<p>
				<input id="comments-submit" type="submit" value="Send">
			</p>

		</div>

	<?php require_once("section/footer.php"); ?>