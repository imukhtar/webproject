	<?php require_once("section/header.php"); ?>
		<p class="con">Jumeirah Vittaveli</p>
		
		<div class="house">
			<div class="rooms"><img src="img/Jumeirah/rooms2.jpg"></div>
			<div class="rooms"><img src="img/Jumeirah/rooms1.jpg"></div>
			<div class="rooms"><img src="img/Jumeirah/rooms4.jpg"></div>
			<div class="rooms"><img src="img/Jumeirah/rooms5.jpg"></div>
			<div class="rooms"><img src="img/Jumeirah/rooms6.jpg"></div>
			<div class="rooms"><img src="img/Jumeirah/rooms7.jpg"></div>

		</div>
		<div class="aboutText">

			<p class="con">About rooms</p>

			<div class="about_hotel">
				<p>Complex Jumeirah Vittaveli offers luxury villas with air conditioning. It offers a common pool and bar Maxi. Guests have access to an exclusive beach, first-rate spa, 4 restaurants, and offers beautiful views.
				</p>
				<p>Guests Resort Jumeirah Vittaveli is organized exclusive service - transfer from Male International Airport by 	   speedboat. The trip takes 20 minutes.
				</p>
			</div>

		</div>
		<hr>

		<div class="comments">

			<h4>Comments</h4>

		</div>
		<hr>

		<div id = "comment" class="comments-form">

			<h4>Write comments</h4>

			<p>
				 <span>
				 	<input id="comments-form-name" type="text" name="name" value="" maxlength="20" size="22" tabindex="1" class="">
				 	<label for="comments-form-name">Name</label>
				 </span>
			</p>
			<p>
				<span>
					<input id="comments-form-email" type="text" name="email" value="" size="22" tabindex="2">
					<label for="comments-form-email">E-Mail</label>
				</span>
			</p>
			<p>
				<form action="comment.php" method="post">
					<textarea id="comments-form-comment" name="comment" cols="65" rows="8" tabindex="5" class=""></textarea>
					<input id="comments-submit" type="submit" name="send" value="Send">
				</form>
			</p>


		</div>
	<?php require_once("section/footer.php"); ?>