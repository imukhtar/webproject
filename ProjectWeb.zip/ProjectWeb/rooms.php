<?php require_once("section/header.php"); ?>
		<p class="con">Rooms</p>
		
		<div class="house">
			
			<div class="rooms"><a href="TajExo.php"><img src="img/TajExo/rooms4.jpg"><p>Taj Exotica Resort & Spa</p></a></div>
			<div class="rooms"><a href="Jumeirah.php"><img src="img/Jumeirah/rooms3.jpg"><p>Jumeirah Vittaveli</p></a></div>
			<div class="rooms"><a href="Loama.php"><img src="img/Loama/rooms6.jpg"><p>Loama Resort Maldives at Maamigili</p></a></div>

		</div>
		<nav>
		  <ul class="pagination">
		    <li>
		      <a href="file:///Users/macbook/Desktop/ProjectWeb/rooms.html" aria-label="Previous">
		        <span aria-hidden="true">&laquo;</span>
		      </a>
		    </li>
		    <li><a href="#">1</a></li>
		    <li>
		      <a href="#" aria-label="Next">
		        <span aria-hidden="true">&raquo;</span>
		      </a>
		    </li>
		  </ul>
		</nav>

<?php require_once("section/footer.php"); ?>	