<?php 
session_start();

require_once("section/header.php");
	
	$conn = mysqli_connect("localhost","root","","Hostt");
			// Check connection
			if (mysqli_connect_errno()){
				echo "Failed to connect to MySQL: " . mysqli_connect_error();
			}

	if (isset($_POST["registerButton"])) {

		$login = $_POST["login"];
		$password1 = $_POST["password1"];
		$password2 = $_POST["password2"];


		// password < 6; sdelat nado!!!
		if ($password1 != $password2) {
			echo "Passwords not right";
		}else if(strlen($login) < 6){
			echo "Your login short";
		}else{

		$sql = "INSERT INTO server (login, password)
		VALUES ('" . $login. "', '" . $password1 . "')";

		if ($conn->query($sql) === TRUE) {
		    echo '<style>';
		    echo '#rooms{visibility:visible;}';
		    echo '</style>';
		    include "rooms.php";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
		}
		}else{
 ?>

		<center>
			<h1>Registration</h1>

			<form method="post">
				<input name="login" type="text" placeholder="Login"><br>
				<input name="password1" type="password" placeholder="Password"><br>
				<input name="password2" type="password" placeholder="Repit Password"><br>
				<input name="registerButton" type="submit" value="Registration">
			</form>

		</center>




<?php
}
 require_once("section/footer.php"); ?>
