<?php 
require_once("section/header.php");?>

<?php $conn = mysqli_connect('localhost','root','','Hostt') or die("Unable to connect");
if (isset($_POST['send'])) {
	$comment = $_POST['comment'];
	$sql = "INSERT INTO comments (comment) VALUES ('".$comment."')";
	if (mysqli_query($conn, $sql)) {
		// $serv = "SELECT * FROM comments WHERE comments = '$comment'";
		// $result = mysql_query($serv);
		// $arr = mysql_fetch_array($result);
		} else {
		echo "Error: " . $sql . "
		" . mysqli_error($conn);
		}
	}if (isset($_POST['send'])) {
		include "Jumeirah.php";
		
		echo '<div style = "position:relative; top:0px; left:200px; width:200px; height:50px; background-color:; font-size:17px; border-radius:5px; border:4px double black;">';
		
	 	echo $comment;

		echo '</div>';
	
} 
require_once("section/footer.php");?>