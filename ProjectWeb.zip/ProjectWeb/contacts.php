<?php require_once("section/header.php"); ?>
		
		<div>
			<p class="con">Contacts</p>
		</div>	
		
		<div id="contact">
			<p>ASTA TRAVEL</p>
			<p>Address: Calvert Trust Exmoor, Wistlandpound, Kentisbury, Barnstaple, Devon, EX31 4SJ </p>
			<p>Call: 3-332-32-32</p>
			<p>Email: asta@gmail.com</p>
			<img src="img/map.png">
		</div>
	
<?php require_once("section/footer.php"); ?>