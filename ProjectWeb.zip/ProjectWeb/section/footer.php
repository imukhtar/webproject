</article>

</div>
	<script type="text/javascript">
		function menu(){
			if(document.getElementById('aside').style.marginLeft != "0px"){
				document.getElementById('aside').style.marginLeft = "0px";
			}else{
				document.getElementById('aside').style.marginLeft = "-200px";
			}
		}

		
	</script>
</body>
</html>
