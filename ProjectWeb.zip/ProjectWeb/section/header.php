<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, minimumscale=1.0, maximum-scale=1.0" />
	<title>Maldives</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- FONTS -->
	<link href='https://fonts.googleapis.com/css?family=Damion' rel='stylesheet' type='text/css'>
	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

	
	<!-- JS -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/npm.js"></script>
	<style type="text/css">
		body{
			background: url(img/saya.png);
		}
		#aside ul a{
			text-decoration: none;
			list-style: none;	
		}
		#aside ul a li{
			text-decoration: none;
		}
		.carousel-caption p{
			font-size: 20px;
		}
		#logo{
			list-style: none;
			text-decoration: none;
		}
		article .news_page img{
			width: calc(33.3% - 25px);
			float: left;
			margin-left: calc(100% - 87%);
		}
		@media screen and (max-width: 720px){
			.carousel-caption p{
				font-size: 10px;
			}
			.carousel-caption h3{
				font-size: 10px;
			}
			.carousel-indicators li{
				width: 5px;
				height: 5px;
			}
		}

	</style>

</head>

<body>

<div id="wrapping" class="shadow">
	<header class="shadow">
		
		<img id="menu1" class="invisible" src="img/hut.png" onclick="menu()">
		
		<div>
			
			<input type="text" placeholder="Write here..." >
			<img src="img/search.png" id="search">	
			
		</div>

		<a href="index.php"><p id="logo">Maldives.com</p></a>


		
	</header>

	<aside class="shadow" id="aside">  
		
		<ul>
			<a href="index.php"> <li> Home </li> </a>
			<a href="contacts.php"> <li> Contacts </li> </a> 
			<a href="registration.php" id="register"> <li> Registration </li> </a> 
			<a href="login.php" id="signin"> <li> Sign in </li> </a> 
			<a href="rooms.php" id = "rooms"> <li> Rooms </li> </a> 
		</ul>

		<ul id="social">
			<a href="http://vk.com"><li><img src="img/vk.png"></li></a>
			<a href="http://facebook.com"><li><img src="img/fb.png"></li></a>
			<a href="http://twitter.com"><li><img src="img/tw.png"></li></a>
			<a href="http://mail.ru"><li><img src="img/mail.png"></li></a>
		</ul>
	</aside>

<!-- ___ !ARTICLE! ___ -->
	<article id="article">