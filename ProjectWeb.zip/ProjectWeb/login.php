<?php 
session_start();

require_once("section/header.php");

$conn = mysqli_connect("localhost","root","","Hostt");
			// Check connection
			if (mysqli_connect_errno()){
				echo "Failed to connect to MySQL: " . mysqli_connect_error();
			}

	if(isset($_POST["loginButton"])){

		$login = $_POST["login"];
		$password = $_POST["password"];

		if (strlen($login) == 0 || strlen($password) == 0){
			echo "You must feel all the input";
		}else{

			$sql = "SELECT * FROM server WHERE login = '".$login."' AND password = '".$password."'  ";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				$_SESSION["login"] = true;
				include "rooms.php";
				echo '<style>';
				echo '#rooms{visibility:visible;}';
				echo '</style>';
			}else{
				echo "error";
			}
		}
	
	}else{
?>
		<center>
			<h1>Login</h1>
			<form method="post">
				<input name="login" type="text" placeholder="Login"><br>
				<input name="password" type="password" placeholder="Password"><br>
				<input name="loginButton" type="submit" value="Login">
			</form>


		</center>



<?php
}
 require_once("section/footer.php"); ?>