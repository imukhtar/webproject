<?php require_once("section/header.php"); ?>
		<p class="con">Taj Exotica Resort & Spa</p>
		
		<div class="house">
			<div class="rooms"><img src="img/TajExo/rooms2.jpg"></div>
			<div class="rooms"><img src="img/TajExo/rooms3.jpg"></div>
			<div class="rooms"><img src="img/TajExo/rooms4.jpg"></div>
			<div class="rooms"><img src="img/TajExo/rooms5.jpg"></div>
			<div class="rooms"><img src="img/TajExo/rooms6.jpg"></div>
			<div class="rooms"><img src="img/TajExo/rooms7.jpg"></div>

		</div>

		<div class="aboutText">
			
			<p class="con">About rooms</p>
			
			<div class="about_hotel">
				<p>The 5-star Resort and Spa Taj Exotica boasts an exquisite service, luxurious villas and a large infinity pool with 	 clear lagoon views. The hotel has 2 restaurants, a bar and a fitness center.
				</p>
			
				<p>Large villas feature private terraces and balconies. They are decorated with elegant wooden furniture and are decorated in warm colors. First-rate amenities include a Nespresso coffee machine and docking station for iPod. Toiletries are provided with premium toiletries and rain shower.
				</p>
			</div>

		</div>
		<hr>

		<div class="comments">

			<h4>Comments</h4>

		</div>
		<hr>

		<div id="comment" class="comments-form">

			<h4>Write comments</h4>

			<p>
				 <span>
				 	<input id="comments-form-name" type="text" name="name" value="" maxlength="20" size="22" tabindex="1" class="">
				 	<label for="comments-form-name">Name</label>
				 </span>
			</p>
			<p>
				<span>
					<input id="comments-form-email" type="text" name="email" value="" size="22" tabindex="2">
					<label for="comments-form-email">E-Mail</label>
				</span>
			</p>
			<p>
				<span>
					<textarea id="comments-form-comment" name="comment" cols="65" rows="8" tabindex="5" class=""></textarea>
				</span>
			</p>
			<p>
				<input id="comments-submit" type="submit" value="Send">
			</p>

		</div>
		<?php require_once("section/footer.php"); ?>